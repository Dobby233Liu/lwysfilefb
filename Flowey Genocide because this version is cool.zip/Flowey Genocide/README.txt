Thanks for downloading my Flowey Genocide fight! I hope you enjoy!

This should be the final version of the fight, at least the final version
with new features. Any updates from this point onward will likely be bug
fixes and other small improvements.

== SPOILER ALERT! ==
This boss fight contains MASSIVE spoilers for both the True Pacifist and
Genocide endings of Undertale. If you have not played Undertale yet, I
highly recommend you play it before you play this fight or watch anything
about it.

Be good, alright?

== Story ==
Like the Genocide run, the fight begins after Flowey sabotages Asgore 
and kills him. He then begs for your mercy, as he has become scared
of you and your murderous personality. However, unlike the Genocide 
ending, rather than taking blow of your attacks, he dodges 
them, continuing to beg for mercy. 

After you continue to ignore his begging, he realises Chara's true
nature and true lack of regard for Asriel in his past life, and determines
that killing you is safer for the greater good, beginning the fight!

== Version 1.0 ==
* First Release

== Version 1.1 ==
- Added a new ending
- Added a 'skip intro' version
- Added some more dialogue
- Added a new 'full intro' (still WIP!)
- Improved some attacks

== Version 1.2 ==
- Replaced the original 'spare' ending
- Improved some attacks
- Changed 'realisation' music
- Added custom item menu

== Version 1.3 ==
- Added some new attacks
- Tweaked some small things
- Replaced the main battle theme
- Removed the 'full intro' (can be enabled in code)
- Improved some other things

== Installation ==
1) Place the 'Flowey Genocide' folder next to this file into 
   the 'Mods' folder of Unitale
2) Done!

== Code Use ==
I am more than happy for you to look at my code as a reference and
develop your own skills and knowledge with it. However, I do NOT
approve of you using my attacks in your own mods, regardless of
whether or not you give credit. This kind of destroy's your mod's
quality and reputation anyway, so you probably shouldn't do that :P

== Credit ==
- Programming, Writing and Design: Romejanic
- Sprites, Characters, Music and Sounds: Toby Fox
- "Left to die" Ending Inspiration: Jared James
- Extra Intro Dialogue: kingvideogames
- "Finale" Remix: Vetrom (Source: https://www.youtube.com/watch?v=06Yug-s1S-0)

== Conclusion ==
Thanks for downloading, I really appreciate it!
Have fun, and stay determined!