comments = {"Flowey is cowering.", "Flowey is begging for mercy.", "Flowey wants you to listen."}
realBattleComments = {"Flowey is taking a stand!", "Flowey is attacking!", "Flowey is ready to fight!"}

commands = {"Check"}

randomdialogue = {}
currentdialogue = nil
require "Libraries/script"
dialogueprefix = "[effect:none][voice:flowey]"

sprite = "flowey/empty"
name = "Flowey"
hp = 10
atk = 1
def = math.huge
xp = 666
check = ""
dialogbubble = "rightwide"
canspare = false
cancheck = false

local finishedDeath = false
local deathStatus   = 2

function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        SetGlobal("didAttack", true)
        canspare = false
        if Encounter.GetVar("floweyDead") then
        	if not finishedDeath then
        		Encounter.Call("StopMusic")
        		SetFlowey("death2")
        	else
        		deathStatus = deathStatus + 1
        		if deathStatus == 9 then
        			Encounter.Call("DoDeathAnimation")
        			SetFlowey("empty")
        			return
        		end
        		SetFlowey("death" .. deathStatus)
                Encounter["attackMaskTimer"] = Encounter["attackMaskTimer"] + 0.125
        	end
        end
    end
end
 
function HandleCustomCommand(command)
    if command == "CHECK" then
    	if finishedDeath then
    		BattleDialog("Just a flower.")
    	else
    		BattleDialog("FLOWEY 99 ATK 1 DEF\nA betrayer.\nHe[w:5] were my best friend.")
    	end
    end
end

function FinishedDeath()
	finishedDeath = true
	canspare = true
end

function SparedDeath()
	BattleDialog("[starcolor:000000][color:000000][noskip][novoice][func:SpawnSpareMask][w:50][func:DissolveFlowey]")
end

function OnDeath()
	hp = 10 * (1 - (deathStatus / 9))
end

function SetFlowey(sprite)
	SetSprite("flowey/" .. sprite)
end

function MakeFloweyEmerge(sprite)
	Encounter.Call("EmergeFlowey", sprite)
end
function MakeFloweyDescend()
	Encounter.Call("DescendFlowey", "empty")
end
function SetSpecialAttack()
	Encounter.SetVar("specialAttack", true)
	-- Don't know why -math.huge doesn't work
	def = 0
end

function EndIntro()
	Encounter.Call("EndIntro")
end

function DoSlash()
	Encounter.Call("AnimateSlash")
end
function StartSpareEnding()
	Encounter.Call("SpawnSpareMask")
end
function KillSpareMask()
	Encounter.Call("KillSpareMask")
end
function KillSpareMaskNow()
	Encounter.Call("KillSpareMaskNow")
end
function CreateFakeSoul()
    Encounter.Call("CreateFakeSoul")
end
function StartSoulRotation()
	Encounter.Call("StartSoulRotation")
end
function FinishSpareEnding()
	Encounter.Call("EndSpare")
end

function PlayMusic(omusic)
	Encounter.Call("StartMusic", omusic)
end
function StopMusic()
	Encounter.Call("StopMusic")
end