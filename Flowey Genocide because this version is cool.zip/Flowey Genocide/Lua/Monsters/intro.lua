comments = {}
commands = {}
randomdialogue = {}

sprite = "asgore/alive"
name = "Asgore"
hp = 1
atk = 1
def = 1
check = "A pathetic goat. Just kill him."
dialogbubble = "right"
canspare = false
cancheck = false

function HandleAttack(attackstatus) end
function HandleCustomCommand(command) end
function OnDeath()
    SetSprite("asgore/death")
end

function BeginDeathAnimation()
	Encounter.Call("StartIntroAnimation")
end
function SpawnSpareMask()
    Encounter.Call("SpawnSpareMask")
end