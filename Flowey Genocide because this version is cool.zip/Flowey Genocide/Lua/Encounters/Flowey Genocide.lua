music = "mus_f_finale_a"
encountertext = "Flowey stands in my way!"
nextwaves = {"dummy"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"flowey","intro"
}

enemypositions = {
{2, 50},
{0,  0},
}

dialogueID = 1
spareDialogueID = 1
intro = true
local watchForAttacks = false
local watchForSpare   = false
specialAttack   	  = false
floweyDead	    	  = false
local missedAttack	  = false
currentState		  = "NONE"
local resultFrom = ""

local skip = _skip or false
-- Enables the full intro, with Asgore's death. As it now has been fixed, it's now not advised to disable this.
local fullIntro = true

playingIntro = false
heartShards = {}

attackOrder   = { "asriel_1", "circle_1", "circle_2", "floweyx_1", "asgore_1", "floweyx_2", "circle_1", "floweyx_5", "circle_2"  }
randomAttacks = { "circle_1", "circle_2", "asgore_1", "floweyx_2", "floweyx_5" }
attackIndex = 1

SetGlobal("didAttack", true)
SetGlobal("realBattle", false)
SetGlobal("difficulty", 0)

local animatingFlowey = false
local isEmerging      = true
local currentFrame    = 1
local frameCounter    = 0
local nextSprite	  = "base"
local floweyLaughing  = false
local floweyMouth     = false
local laughTimer	  = 0

local floweySpared = false

local playerSoul = nil
local soulAngle  = 0
local soulDist   = 0
local soulRotating   = false
local soulDistTarget = 70
local soulMoveSpeed  = 50
local destroyed3PP = 0
local toppestSpeedSpin = 3
local soulMul = toppestSpeedSpin
local maxValMul = 5 * toppestSpeedSpin
local ppDelayTime = 0.32

local whiteMask = nil
local attackMask = nil
attackMaskTimer = 0
local attackMaskBullet = nil
local spareMask = nil
local spinShades = {}

playerskipdocommand = true

deathmusic = "mus_wind"
deathtext = "[noskip]"

local inventoryItems = {"Pie","Steak","I. Noodles","T. Dog"}
local fuckedUpMonologue = { 
"[color:ff0000]\nI can feel it wriggling.", 
"\nYou hear a pathetic yelp.",
"\nYou hear it whimpering...",
"[color:ff0000]\nRight where it belongs."
}

require "Libraries/music_twopart"
require "Libraries/fakeui_highlight"

function EncounterStarting()
    if isCYF then
        local boolet = CreateSprite("empty")
        boolet.Remove()
        if boolet.isactive then error("This modded mod may not perform well in CYF's retromode. You probably want to disable it.")
        elseif GetAlMightyGlobal("CrateYourFrisk") then error("You're in Crate Your Frisk mode. You probably want to clear the AlMighty globals.") end
    else
        error("This mod is modified for CYF. It is excepted to be run under CYF.")
    end

   	StopMusic()

   	Player.lv = 20
   	Player.maxhp = 99
   	Player.hp = 99
   	
   	Inventory.AddCustomItems(inventoryItems,{0,0,0,0})
   	Inventory.SetInventory(inventoryItems)
   	
    Player.name = "Chara" -- forces the name to be "Chara". Must have in CYF as it's now always Rhenao.

	attackMask = CreateSprite("px", "BelowArena")
	attackMask.MoveToAbs(320,240)
	attackMask.Scale(640,480)
	attackMask.color = {0,0,0}
	attackMask.alpha = 0
	InitFakeUI()

    if not skip then
		if not fullIntro then
			enemies[2].Call("SetActive", false)
			enemies[2].Call("SetSprite", "empty")
			nextwaves = { "dummy" }
			enemies[1].Call("SetActive", true)
            SpawnSpareMask()
            spareMask.alpha = 1
		    Player.sprite.alpha = 0
		    IntroFloweyDialogue()
		else
			enemies[1].Call("SetActive", false)
            enemies[2]["monstersprite"].layer = "BelowBullet"
            SpawnSpareMask()
	    	enemies[2].SetVar("currentdialogue",{
	    	"[effect:none][voice:asgore][waitall:2]Why...[w:20]\nYou...","[noskip][func:BeginDeathAnimation][func:State,DEFENDING][next]"
	    	})
		end
	else
		enemies[2].Call("SetActive", false)
		enemies[2].Call("SetSprite", "empty")
		dialogueID = 17
		SetGlobal("realBattle", true)
		LoadNextAttack()
		SpawnSpareMask()
		spareMask.alpha = 1
		Player.sprite.alpha = 0
		enemies[1].SetVar("comments", enemies[1].GetVar("realBattleComments"))
		enemies[1].SetVar("currentdialogue",ProcessSpeech(enemies[1]["shortIntroDialogue"]))
	end
	State("ENEMYDIALOGUE")
end

function PlayIntro()
	playingIntro = true
    wavetimer = math.huge
    nextwaves = {"intro"}
    State("DEFENDING")
end
function IntroFloweyDialogue()
    enemies[1].SetVar("currentdialogue",ProcessSpeech(enemies[1]["introDialogue"]))
end
function EndIntro()
    intro = false
    KillSpareMaskNow()
    if not GetGlobal("realBattle") then
        -- TODO: consider mus_wind
        StartMusic("mus_prebattle1")
        Audio.Pitch(0.25)
    end
    --SetAction("FIGHT")
end

function Update()
	TickFloweyAnimation()
	-- Manage intro heart shard
    if fullIntro then
    	UpdateHeartShards()
    end
    UpdateFakeUI()
	
	UpdateMusic()
	
    Player.hp = Player.maxhp -- DEBUG

    for i=1,#spinShades do
        local spinShade = spinShades[i]
        if spinShade.isactive then
            if spinShade.alpha <= 0 then
                spinShade.Remove()
            else
                spinShade.alpha = spinShade.alpha - 0.25
            end
        end
    end

	if playerSoul != nil and playerSoul.isactive then
		if soulRotating then
            local prevSoulAngle = soulAngle
		    soulAngle = soulAngle + 90 * Time.dt
			if soulDist > math.ceil(soulDistTarget) then
				soulDist = soulDist - (soulMoveSpeed * Time.dt)
				if soulDist < math.ceil(soulDistTarget) then
					soulDist = math.ceil(soulDistTarget)
				end
			end
			if whiteMask != nil and whiteMask.isactive then
			    Audio.Pitch(1.25 + (destroyed3PP * 2));
			    if destroyed3PP <= ppDelayTime then
                    Audio.Volume(destroyed3PP / ppDelayTime)
                else
                    Audio.Volume(1 - (destroyed3PP / 4));
                end
                soulMoveSpeed = 50 * (5-destroyed3PP) * (4*destroyed3PP + 0.75)
				whiteMask.alpha = (destroyed3PP - ppDelayTime) / 1.5
                if soulDistTarget > 0 then
                    local lol = (destroyed3PP / 2 / 0.008 * 0.005)
                    soulDistTarget = soulDistTarget - lol
                    if soulMul < maxValMul then soulMul = soulMul + 0.25 end
                    soulAngle = soulAngle + ((soulAngle - prevSoulAngle) * (maxValMul - (destroyed3PP * toppestSpeedSpin) - 1))
                    CreateFakeSoulShadow()
                end
				if destroyed3PP >= 4.20 then -- 42069
                    Audio.Stop()
                    Audio.StopAll()
					error("\n\tThe timeline you are trying to access has been destroyed or reset.\n\t<color=#ff0000ff>* That was fun. Let's do it again.</color>")
				end
                destroyed3PP = destroyed3PP + 0.008
			end
			local a = math.rad(soulAngle)
			local c = math.cos(a)
			local s = math.sin(a)
			Player.MoveToAbs(320+(c*soulDist), 320+(s*soulDist), true)
		end
		playerSoul.MoveToAbs(Player.absx, Player.absy)
		-- Visual hax
		if playerSoul.absy >= 240 and playerSoul.layer != "BelowArena" then
		    playerSoul.layer = "BelowArena"
		end
	end
	
	if floweyDead then
		watchForAttacks = false
	end
	
	if watchForAttacks and Input.Confirm == 1 and (isEmerging or specialAttack) then
		if not specialAttack then
			DescendFlowey("empty")
		else
			EmergeFlowey("death1")
			floweyDead = true
		end
		watchForAttacks = false
		floweySpared 	= false
	end
	if watchForSpare and Input.Confirm == 1 then
		if not floweyDead then
			enemies[1].SetVar("currentdialogue", ProcessSpeech(enemies[1]["spareEndingDialogue"]))
			floweySpared = true
		    State("ENEMYDIALOGUE")
		elseif GetGlobal("didAttack") then
            BattleDialog({"[starcolor:ff0000][color:ff0000]Just finish it.","[noskip][func:State,ACTIONSELECT][next]"})
        else
		    State("ENEMYDIALOGUE")
        end
		watchForSpare = false
	end

	if currentState == "DEFENDING" and attackMaskTimer < 0.75 and GetGlobal("realBattle") and (not (#nextwaves > 0) or not (nextwaves[1] == "dummy")) and not floweyDead then
		attackMaskTimer = attackMaskTimer + Time.dt*3
		if attackMaskTimer > 0.75 then
			attackMaskTimer = 0.75
		end
	elseif currentState != "DEFENDING" and attackMaskTimer > 0 and not floweyDead then
		attackMaskTimer = attackMaskTimer - Time.dt*3
		if attackMaskTimer < 0 then
			attackMaskTimer = 0
		end
	end
	attackMask.alpha = attackMaskTimer

    if spareMask != nil and spareMask.isactive then
        if spareMask.GetVar("fadeout") then
            if spareMask.alpha <= 0 then
                spareMask.Remove()
                spareMask = nil
            else
                spareMask.alpha = spareMask.alpha - 0.03125
                Player.sprite.alpha = Player.sprite.alpha + 0.03125
                return
            end
        elseif spareMask.alpha < 1 then
            spareMask.alpha = spareMask.alpha + 0.03125
            Player.sprite.alpha = Player.sprite.alpha - 0.03125
        end
    else
        Player.sprite.alpha = 1
    end
end

function UpdateHeartShards()
	for i=1,#heartShards do
		local shard = heartShards[i]
		if shard.isactive then
            local dir = shard.GetVar("dir")
			local dirX = dir[1]
			local dirY = dir[2] - 2.5*Time.dt
			local realX = shard.absx + dirX
			local realY = shard.absy + dirY
            shard.MoveToAbs(realX, realY)
			if shard.absy <= -shard.height then
				shard.Remove()
			end
			dir[2] = dirY
            shard.SetVar("dir", dir)
		end
	end
end

function TickFloweyAnimation()
	if animatingFlowey then
		frameCounter = frameCounter - Time.dt
		if frameCounter <= 0 then
			currentFrame = currentFrame + 1
			frameCounter = 1/20
		end
		local sprite = "empty"
		if currentFrame > 9 then
			sprite = nextSprite
			animatingFlowey = false
		else
			sprite = "emerge" .. currentFrame
			if not isEmerging then
				sprite = "emerge" .. (10 - currentFrame)
			end
		end
		if sprite == nil then
			sprite = nextSprite
		end
		enemies[1].Call("SetSprite", "flowey/" .. sprite)
	elseif floweyLaughing then
		laughTimer = laughTimer + 1
		if laughTimer%5 == 0 then
			floweyMouth = not floweyMouth
		    enemies[1].Call("SetFlowey", floweyMouth and "grin2" or "grin1")
		end
	end
end
function AnimateFlowey(emerging, sprite)
	animatingFlowey = true
	isEmerging 		= emerging
	currentFrame	= 1
	frameCounter	= 0
	nextSprite		= sprite
end
function EmergeFlowey(sprite)
	AnimateFlowey(true,sprite)
end
function DescendFlowey(sprite)
	AnimateFlowey(false,sprite)
end

function EnemyDialogueStarting()
	if not floweyDead and floweySpared then
		return
	end
	if floweyDead and not GetGlobal("didAttack") then
        attackMaskTimer = attackMaskTimer + 0.125
		enemies[1].SetVar("currentdialogue", ProcessSpeech(enemies[1].GetVar("spareDialogue")[spareDialogueID]))
		spareDialogueID = spareDialogueID + 1
		return
	end
	if specialAttack and not floweyDead then
		enemies[1].SetVar("currentdialogue", ProcessSpeech({
		"[func:MakeFloweyEmerge,grin2]Still here?[func:SetFlowey,grin1]",
		"[func:SetFlowey,evil2][effect:shake]GET READY![func:SetFlowey,evil1]"
		}))
		missedAttack = true
	end
	if not isEmerging and not animatingFlowey and not intro then
		EmergeFlowey("intro1")
	end
	if not intro and GetGlobal("didAttack") then
		if floweySpared then
			StopMusic()
		end
		enemies[1].SetVar("currentdialogue", ProcessSpeech(enemies[1]["floweyDialogue"][dialogueID]))
		if dialogueID == 10 then
			enemies[1].SetVar("canspare", true)
		elseif dialogueID == 16 then
			SetGlobal("realBattle", true)
			StopMusic()
			enemies[1].SetVar("comments", enemies[1].GetVar("realBattleComments"))
		end
		dialogueID = dialogueID + 1
		SetGlobal("didAttack", false)
	end
	if intro then
		SetGlobal("didAttack", false)
		if skip then
			intro = false
		end
	end
end

function EnemyDialogueEnding()
	LoadNextAttack()
end

function LoadNextAttack()
    if (playingIntro or intro) and fullintro then
		nextwaves = {"intro"}
	elseif floweyDead then
		nextwaves = { "dummy" }
	elseif specialAttack and missedAttack then
		nextwaves = { "special" }
	elseif GetGlobal("realBattle") then
		SetGlobal("difficulty", GetGlobal("difficulty") + 1)
		if attackIndex <= #attackOrder then
			nextwaves = { attackOrder[attackIndex] }
			attackIndex = attackIndex + 1
		else
			nextwaves = { randomAttacks[math.random(#randomAttacks)] }
		end
	else
		nextwaves = { "dummy" }
	end
end

function DefenseEnding()
    GenerateFlavorText()
    enemies[1].Call("SetActive", true)
end

function EnteringState(newstate, oldstate)
	watchForAttacks = newstate == "ATTACKING"
	watchForSpare   = (enemies[1].GetVar("canspare") or floweyDead) and newstate == "MERCYMENU"
	currentState	= newstate
	if newstate == "ITEMMENU" then
	    if floweyDead then
	    	BattleDialog("[starcolor:ff0000][color:ff0000]Just finish it.")
		end
	end
	if newstate == "DIALOGRESULT" then
		resultFrom = oldstate
	end
    if oldstate == "DIALOGRESULT" then
        if resultFrom == "ITEMMENU" then
            State("ACTIONSELECT")
        end
        resultFrom = ""
    end
	if newstate == "ENEMYDIALOGUE" and not GetGlobal("didAttack") and not specialAttack and not intro and not floweySpared then
		State("DEFENDING")
	elseif newstate == "ENEMYDIALOGUE" and GetGlobal("realBattle") and enemies[1]["floweyDialogue"][dialogueID] == nil and not intro then
		if floweyDead then
			if not GetGlobal("didAttack") then
				return
			end
			State("ACTIONSELECT")
			return
		end
		LoadNextAttack()
		State("DEFENDING")
	end
	if newstate == "DEFENDING" and not GetGlobal("realBattle") and not intro then
		GenerateFlavorText()
		if not floweySpared then
			State("ACTIONSELECT")
		end
	end
	if newstate == "ENEMYDIALOGUE" and not isEmerging and not specialAttack then
		EmergeFlowey("base")
	end
end

function HandleSpare()
  	if floweyDead then
		BattleDialog({"[starcolor:ff0000][color:ff0000]Just finish it.","[noskip][func:State,ACTIONSELECT][next]"})
	else
	    State("ACTIONSELECT")
	end
end

function HandleItem(command)
	if command == "PIE" then
		BattleDialog("You ate the Butterscotch Pie.[w:5]\n" .. ItemHeal(99))
	elseif command == "STEAK" then
		BattleDialog("You ate the Face Steak.[w:5]\n" .. ItemHeal(60))
	elseif command == "I. NOODLES" then
		BattleDialog("They're better dry.[w:5]\n" .. ItemHeal(90))
	elseif command == "T. DOG" then
		BattleDialog("You ate the Test Dog.[w:5]" .. fuckedUpMonologue[math.random(#fuckedUpMonologue)] ..
		"[w:5]\n[color:ffffff]" .. ItemHeal(45))
	end
end

function ItemHeal(amount)
	Player.Heal(amount)
	if Player.hp >= Player.maxhp then
		return "Your HP was maxed out!"
	end
	return "You recovered " .. amount .. " HP."
end

function ProcessSpeech(dialogue)
	if dialogue == nil then
		return dialogue
	end
	for i=1,#dialogue do
		dialogue[i] = dialogue[i]:gsub("<player>", Player.name)
		dialogue[i] = dialogue[i]:gsub("<p2>"	 , Player.name:sub(1,2))
	end
	return dialogue
end

local charaMonologue = {
"Back off.",
"Asriel, back off.",
"Asriel, stop it.",
"Asriel, you can't stop me.",
"Asriel, you can't help me.",
"Asriel, leave me alone.",
"Asriel, I'm going to kill you.",
"Asriel, stop."
}
function GenerateFlavorText()
	if floweyDead then
		encountertext = "..."
	elseif specialAttack then
		encountertext = "Flowey is preparing a stronger\rattack."
	elseif enemies[1].GetVar("canspare") then
		encountertext = "Flowey is sparing you."
	else
    	encountertext = RandomEncounterText()
        if math.random() <= 0.1 then
        	encountertext = "[starcolor:ff0000][color:ff0000]" .. charaMonologue[math.random(#charaMonologue)]
        end
        if math.random() <= 0.1 then
        	encountertext = encountertext:gsub("Flowey", "Asriel")
        end
    end
end

function AnimateSlash()
	Player.ForceAttack(1,0)
end

function SpawnSpareMask()
    if spareMask != nil and spareMask.isactive then
        return
    end
	CreateLayer("TheFuckingSpareMask", "BelowPlayer", true)
	spareMask = CreateSprite("px", "TheFuckingSpareMask", 1)
	spareMask.MoveToAbs(320, 120)
	spareMask.Scale(640, 240)
	spareMask.color = {0,0,0}
	spareMask.alpha = 0
end
function AnotherWorkaroundWhatTheFuck()
    if spareMask == nil or not spareMask.isactive then
        spareMask = nil
        return
    end
    spareMask.layer = "Top"
end
function KillSpareMask()
    if spareMask == nil or not spareMask.isactive then
        spareMask = nil
        return
    end
    spareMask.SetVar("fadeout", true)
end
function KillSpareMaskNow()
    if (spareMask == nil) or (not spareMask.isactive) then
        spareMask = nil
        return
    end
    Audio.PlaySound("click")
    spareMask.SetVar("fadeout", false)
    spareMask.alpha = 0
    spareMask.Remove()
    spareMask = nil
    Player.sprite.alpha = 1
end
function CreateFakeSoul()
    -- There was an attempt to PUT THE FUCKING SOUL UNDER THE DIALOG BUBBLE
	CreateLayer("TheFuckingSpareMasaa", "TheFuckingSpareMask")
	playerSoul = CreateSprite("ut-heart", "TheFuckingSpareMasaa", 0)
	playerSoul.MoveToAbs(Player.absx, Player.absy)
	playerSoul.color = Player.sprite.color
	Player.sprite.layer = "Bottom"
	Player.sprite.alpha = 0
    if (spareMask == nil) or (not spareMask.isactive) then
        spareMask = nil
        return
    end
    Audio.PlaySound("click")
    spareMask.alpha = 1
end
function StartSoulRotation()
	local xd = 320 - playerSoul.absx
	local yd = 320 - playerSoul.absy
	soulDist  = math.sqrt(xd*xd+yd*yd)
	soulAngle = -90
	soulRotating = true
end
function CreateFakeSoulShadow()
	local spinShade = CreateSprite("ut-heart", "TheFuckingSpareMask", 1)
	spinShade.MoveToAbs(Player.absx, Player.absy)
	spinShade.color = Player.sprite.color
	spinShade.alpha = 0.5
	table.insert(spinShades, spinShade)
end
function SpawnWhiteMask()
	whiteMask = CreateSprite("px", "Top")
	whiteMask.MoveToAbs(320, 240)
	whiteMask.Scale(640, 480)
	whiteMask.color = {1,1,1}
	whiteMask.alpha = 0
end
function EndSpare()
	--Audio.PlaySound("fadeout")
	Audio.PlaySound("flowey_laugh")
	--soulMoveSpeed  = 10
	--soulDistTarget = 0
	floweyLaughing = true
    Audio.Stop()
    -- This should be mus_cymbal, but I think this one sounds better
    Audio.LoadFile("mus_f_destroyed3")
    Audio.Pitch(1.25)
    Audio.Volume(1)
    Audio.Play()
	SpawnWhiteMask()
end

function DoDeathAnimation()
	BattleDialog("[novoice][noskip][starcolor:000000][color:000000][w:50][func:SpawnSpareMask][func:AnotherWorkaroundWhatTheFuck][w:50][func:DissolveFlowey][w:200][func:State,DONE][next]")
end
function DissolveFlowey()
	enemies[1].Call("Kill")
	BattleDialog("[starcolor:000000][color:000000][noskip][novoice][w:200][func:State,DONE]")
end

function StartMusic(omusic)
    --DEBUG(omusic)
	if omusic == "main" then
        Audio.Pitch(1)
	    LoadMusic("mus_f_finale_a","mus_f_finale_b")
	    return
	else
		LoadMusic(nil,omusic)
		if omusic == "mus_prebattle1" then
            Audio.Pitch(0.22)
        else
            Audio.Pitch(1)
        end
        Audio.Volume(0.75)
	end
end

function BeforeDeath()
    Audio.StopAll()
end