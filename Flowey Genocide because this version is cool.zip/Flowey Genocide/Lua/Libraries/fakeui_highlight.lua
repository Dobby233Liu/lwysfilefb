local selectedbtn = 0
local lastselected = 0
local buttons = {}
fui_visible = false

local baseX = {32,185,345,500}

function InitFakeUI()
	for i=1,4 do
		buttons[i] = CreateSprite("ui/"..i, "BelowPlayer")
		buttons[i].alpha = 0
	    buttons[i].MoveTo(baseX[i] + (buttons[i].width / 2), 6 + (buttons[i].height / 2))
	end
end

function UpdateFakeUI()
    if not fui_visible then
		for i=1,#buttons do
			if buttons[i].alpha > 0 or buttons[i].alpha < 0 then buttons[i].alpha = 0 end
		end
		return
    end

    local fuistate = GetCurrentState()
	if(fuistate == "ACTIONSELECT" and Player.absy == 25) then
		if(Player.absx >= 515) then
			selectedbtn = 4
		elseif(Player.absx >= 361) then
			selectedbtn = 3
		elseif(Player.absx >= 202) then
			selectedbtn = 2
		elseif(Player.absx >= 48 or Player.absx <= 48) then
			selectedbtn = 1
		end
	    --[[elseif (fuistate == "ENEMYDIALOGUE" or fuistate == "DEFENDING") then
		selectedbtn = 0 The MERCY option needs to be showed ]]
	end
	if(selectedbtn ~= lastselected) then
		for i=1,#buttons do
			buttons[i].alpha = selectedbtn == i and 1 or 0
		end
	end
	lastselected = selectedbtn
end