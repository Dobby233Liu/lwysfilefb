local parta = nil
local partb = nil
isparta  = true

function LoadMusic(newparta,newpartb)
	parta = newparta
	partb = newpartb
	isparta  = true
	lastTime = 0

    Audio.LoadFile(partb)
    if parta == nil then
		isparta = false
    else
    	Audio.LoadFile(parta)
    end
    Audio.Play()
end

function StopMusic()
	Audio.Stop()
end
function PlayMusic()
	Audio.Play()
end

function UpdateMusic()
	if isparta and Audio.playtime >= (Audio.totaltime - Time.dt) then
        isparta = false
		Audio.LoadFile(partb)
        Audio.Play()
	end
end