-- WARNING: DESPITE LOOKING LIKE A WAVE SCRIPT, THIS IS ACTUALLY RUN IN THE ENCOUNTER CONTEXT!!!

heartShards = {}
heartShardDirections = {}

function UpdateHeartShards()
	for i=1,#heartShards do
		local shard = heartShards[i]
		if shard.isactive then
            local dir = heartShardDirections[i]
			local dirX = dir[1]
			local dirY = dir[2] - 2.5*Time.dt
			local realX = shard.absx + dirX
			local realY = shard.absy + dirY
            shard.MoveToAbs(realX, realY)
			if shard.absy <= -shard.height then
				shard.Remove()
			end
			heartShardDirections[i][2] = dirY
		end
	end
end

function ExplodeAsgoreHeart(x,y)
    Audio.PlaySound("heartsplosion")
	for i=1,6 do
		local shard = CreateSprite("UI/Battle/heartshard_0", "BelowBullet")
		shard.MoveToAbs(x,y)
		local dirX = 2*(math.random()*2-1)
		local dirY = 2+math.random()*2
		table.insert(heartShardDirections, {dirX, dirY})
		if math.random() < 0.5 then
			shard.SetAnimation({"UI/Battle/heartshard_0","UI/Battle/heartshard_1"},1/10)
		else
			shard.SetAnimation({"UI/Battle/heartshard_2","UI/Battle/heartshard_3"},1/10)
		end
		table.insert(heartShards, shard)
	end
end

local bullets = {}
local bulletCount = 0
local spawntimer = 0

local pelletDist = 150
local pelletCenterX = 320
local pelletCenterY = 325

local spawnPellets = true
playingIntro = false

function UpdateIntro()
	if not playingIntro then
		return
	end

    -- Force a skip
    if Input.Cancel == 1 and spawntimer > 0 and spawntimer < 650 then
        spawntimer = 659
        enemies[1].Call("SetActive",true)
		enemies[2].Call("SetSprite","empty")
        enemies[2].Call("SetActive",false)
		if asgoreSoul.isactive then asgoreSoul.Remove() end
        return
    end

    if spawnPellets and spawntimer%1 == 0 and bulletCount < 36 then
		local spawnAngle = math.rad((360 / 36) * spawntimer)
		local posX = pelletCenterX + math.cos(spawnAngle) * pelletDist
		local posY = pelletCenterY + math.sin(spawnAngle) * pelletDist
		local bullet = CreateSprite("attacks/pellet_1", "BelowBullet")
		bullet.MoveToAbs(posX, posY)
		bullet.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
		bullet.SetVar("angle", spawnAngle)
		table.insert(bullets, bullet)
		Audio.PlaySound("pellet")
		bulletCount = bulletCount + 1
	end

	if spawntimer == 0 then
		enemies[1].Call("SetActive",true)
	    enemies[2].Call("SetSprite","asgore/shock")
		asgoreSoul = CreateSprite("ut-heart", "BelowBullet")
		asgoreSoul.MoveToAbs(pelletCenterX, pelletCenterY)
        asgoreSoul.rotation = 180
        asgoreSoul.alpha = 0
    end

	spawntimer = spawntimer + 1

    if spawntimer >= 75 then
		spawnPellets = false
	end

	if spawntimer == 75 then
		enemies[2].Call("SetSprite","asgore/death")
		Audio.PlaySound("hitsound")
		bulletCount = 36
		pelletDist = 0
		for i=1,#bullets do
			if bullets[i].isactive then
				bullets[i].Remove()
			end
		end
	elseif spawntimer == 145 then
		enemies[2].Call("Kill")
	end

	if spawntimer > 215 and asgoreSoul.isactive and asgoreSoul.alpha < 1 then
		asgoreSoul.alpha = asgoreSoul.alpha + Time.dt
		if asgoreSoul.alpha > 1 then
			asgoreSoul.alpha = 1
		end
	end
	if spawntimer < 390 and asgoreSoul.isactive then
	    local gyrateDist = 2.5
		asgoreSoul.MoveToAbs(pelletCenterX + math.random(-gyrateDist,gyrateDist), pelletCenterY + math.random(-gyrateDist,gyrateDist))
	end

	if spawntimer >= 390 and spawntimer < 450 and asgoreSoul.isactive then
		asgoreSoul.MoveToAbs(pelletCenterX, pelletCenterY)
		spawnPellets = true
        if spawntimer == 390 then
	    	pelletDist = 75
    		bulletCount = 0
        end
    end
    if spawntimer > 450 then
		spawnPellets = false
    end

	if spawntimer == 460 then
		asgoreSoul.Set("ut-heart-broken")
		Audio.PlaySound("heartbeatbreaker")
		for i=1,#bullets do
			if bullets[i].isactive then
				bullets[i].Remove()
			end
		end
	elseif spawntimer == 560 then
	    ExplodeAsgoreHeart(asgoreSoul.absx, asgoreSoul.absy)
		asgoreSoul.Remove()
	elseif spawntimer == 660 then
		nextwaves = {"dummy"}
		for i=1,#bullets do
			if bullets[i].isactive then
				bullets[i].Remove()
			end
		end
    elseif spawntimer == 661 then
        playingIntro = false
        enemies[1].Call("SetActive",true)
        IntroFloweyDialogue()
		State("ENEMYDIALOGUE")
	end

	if pelletDist > 0 and (spawntimer > 40 and spawntimer < 75) or (spawntimer > 430 and spawntimer < 450) then
		pelletDist = pelletDist - Time.dt*150
	end

	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local spawnAngle = bullet.GetVar("angle")
			local posX = pelletCenterX + math.cos(spawnAngle) * pelletDist
			local posY = pelletCenterY + math.sin(spawnAngle) * pelletDist
			bullet.MoveToAbs(posX, posY)
			if pelletDist <= 0 then
				bullet.Remove()
			end
		end
	end
end

function PlayIntro()
	playingIntro = true
    wavetimer = math.huge
    nextwaves = {"intro"}
end