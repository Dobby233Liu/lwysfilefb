spawntimer = 0
bullets = {}

Encounter.SetVar("wavetimer", 4.0)

function Update()
    spawntimer = spawntimer + 1
    if spawntimer%10 == 0 then
    	local posx = 20 * math.sin(Time.time)
    	local bullet = nil
    	if math.random() > 0.5 then
        	local posy = Arena.height/2
        	bullet = CreateProjectile("attacks/pellet_1", posx, posy)
        	bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
        	bullet.SetVar("dir", 0)
        else
        	local posy = -Arena.height/2
        	bullet = CreateProjectile("attacks/pellet_2", posx, posy)
        	bullet.sprite.SetAnimation({"attacks/pellet_2","attacks/pellet_1"},1/12.5)
        	bullet.SetVar("dir", 1)
        end
        table.insert(bullets, bullet)
    end
    
    for i=1,#bullets do
        local bullet = bullets[i]
        local frames = bullet.GetVar("frames")
        if frames == nil then
        	frames = 0
        end
        local newposy = bullet.y - 1
        if bullet.GetVar("dir") == 1 then
        	newposy = bullet.y + 1
        end
        local newposx = lerp(20, Arena.width/2 - 8, clamp(frames, 0, 120) / 120) * math.sin(Time.time * 2 + i)
        if newposy < -Arena.height/2 + 8 then
        	newposy = -Arena.height/2 + 8
        elseif newposy > Arena.height/2 - 8 then
        	newposy = Arena.height/2 - 8
        end
        frames = frames + 1
        bullet.MoveTo(newposx, newposy)
        bullet.SetVar("frames", frames)
    end
end

function OnHit(bullet)
	Player.Hurt(1, 0)
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function clamp(x, a, b)
	if x < a then
		return a
	elseif x > b then
		return b
	else return x
	end
end