local spawntimer = 0

local bullets = {}
local bulletCount = 0
local pelletDist = 150
local pelletCenterX = 320
local pelletCenterY = 325
local spawnPellets = true

function Update()
    -- Force a skip
    if Input.Cancel == 1 and spawntimer > 0 and spawntimer < 650 then
        spawntimer = 659
        Encounter["enemies"][1].Call("SetActive",true)
		Encounter["enemies"][2].Call("SetSprite","empty")
        Encounter["enemies"][2].Call("SetActive",false)
		if asgoreSoul.isactive then asgoreSoul.Remove() end
        return
    end

    if spawnPellets and spawntimer%1 == 0 and bulletCount < 36 then
		local spawnAngle = math.rad((360 / 36) * spawntimer)
		local posX = pelletCenterX + math.cos(spawnAngle) * pelletDist
		local posY = pelletCenterY + math.sin(spawnAngle) * pelletDist
		local bullet = CreateSprite("attacks/pellet_1", "BelowBullet")
		bullet.MoveToAbs(posX, posY)
		bullet.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
		bullet.SetVar("angle", spawnAngle)
		table.insert(bullets, bullet)
		Audio.PlaySound("pellet")
		bulletCount = bulletCount + 1
	end

	if spawntimer == 0 then
		Encounter["enemies"][1].Call("SetActive",true)
	    Encounter["enemies"][2].Call("SetSprite","asgore/shock")
		asgoreSoul = CreateSprite("ut-heart", "BelowBullet")
		asgoreSoul.MoveToAbs(pelletCenterX, pelletCenterY)
        asgoreSoul.rotation = 180
        asgoreSoul.alpha = 0
    end

	spawntimer = spawntimer + 1

    if spawntimer >= 75 then
		spawnPellets = false
	end

	if spawntimer == 75 then
		Encounter["enemies"][2].Call("SetSprite","asgore/death")
		Audio.PlaySound("hitsound")
		bulletCount = 36
		pelletDist = 0
		for i=1,#bullets do
			if bullets[i].isactive then
				bullets[i].Remove()
			end
		end
	elseif spawntimer == 145 then
		Encounter["enemies"][2].Call("Kill")
	end

	if spawntimer > 215 and asgoreSoul.isactive and asgoreSoul.alpha < 1 then
		asgoreSoul.alpha = asgoreSoul.alpha + Time.dt
		if asgoreSoul.alpha > 1 then
			asgoreSoul.alpha = 1
		end
	end
	if spawntimer < 390 and asgoreSoul.isactive then
	    local gyrateDist = 2.5
		asgoreSoul.MoveToAbs(pelletCenterX + math.random(-gyrateDist,gyrateDist), pelletCenterY + math.random(-gyrateDist,gyrateDist))
	end

	if spawntimer >= 390 and spawntimer < 450 and asgoreSoul.isactive then
		asgoreSoul.MoveToAbs(pelletCenterX, pelletCenterY)
		spawnPellets = true
        if spawntimer == 390 then
	    	pelletDist = 75
    		bulletCount = 0
        end
    end
    if spawntimer > 450 then
		spawnPellets = false
    end

	if spawntimer == 460 then
		asgoreSoul.Set("ut-heart-broken")
		Audio.PlaySound("heartbeatbreaker")
		for i=1,#bullets do
			if bullets[i].isactive then
				bullets[i].Remove()
			end
		end
	elseif spawntimer == 560 then
	    ExplodeHeart(asgoreSoul)
		asgoreSoul.Remove()
	elseif spawntimer == 660 then
		nextwaves = {"dummy"}
		for i=1,#bullets do
			if bullets[i].isactive then
				bullets[i].Remove()
			end
		end
    elseif spawntimer == 661 then
        Encounter["playingIntro"] = false
        Encounter["enemies"][1].Call("SetActive",true)
        Encounter.Call("IntroFloweyDialogue")
        EndWave()
		State("ENEMYDIALOGUE")
	end

	if pelletDist > 0 and (spawntimer > 40 and spawntimer < 75) or (spawntimer > 430 and spawntimer < 450) then
		pelletDist = pelletDist - Time.dt*150
	end

	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local spawnAngle = bullet.GetVar("angle")
			local posX = pelletCenterX + math.cos(spawnAngle) * pelletDist
			local posY = pelletCenterY + math.sin(spawnAngle) * pelletDist
			bullet.MoveToAbs(posX, posY)
			if pelletDist <= 0 then
				bullet.Remove()
			end
		end
	end
end

-- Update of the shards is done in Encounter instead to prevent the animation freezing
function ExplodeHeart(heart)
    Audio.PlaySound("heartsplosion")
    local x = heart.absx
    local y = heart.absy
    local shards = {}
	for i=1,6 do
		local shard = CreateSprite("UI/Battle/heartshard_0", "BelowBullet")
		shard.MoveToAbs(x,y)
		local dirX = 2*(math.random()*2-1)
		local dirY = 2+math.random()*2
		shard.SetVar("dir", {dirX, dirY})
		if math.random() < 0.5 then
			shard.SetAnimation({"UI/Battle/heartshard_0","UI/Battle/heartshard_1"},1/10)
		else
			shard.SetAnimation({"UI/Battle/heartshard_2","UI/Battle/heartshard_3"},1/10)
		end
        shard.color = heart.color
		table.insert(shards, shard)
	end
    Encounter.SetVar("heartShards", shards)
end

function OnHit(nope)
     -- The wave even doesn't have bullets
end