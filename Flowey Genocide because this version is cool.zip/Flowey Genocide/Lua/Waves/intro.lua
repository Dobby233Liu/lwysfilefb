--[[
Waits for the intro animation in the Encounter region.
(don't ask me why)
]]--

function Update() end