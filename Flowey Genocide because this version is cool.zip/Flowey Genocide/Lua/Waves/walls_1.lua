spawntimer = 0
bullets = {}

Encounter.SetVar("wavetimer", 4.0)

function Update()
    spawntimer = spawntimer + 1

    --[[if spawntimer < 50 then
    	return
    end]]

    if spawntimer%10 == 0 then
    	local x = 0.5 + 0.5 * math.sin(Time.time * 5)
    	local y = 12.5
    
        local posx = Arena.width/2
        local posy = lerp(Arena.height/2, y, x)
        local bullet = CreateProjectile("attacks/pellet_1", posx, posy)
        bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
        bullet.SetVar("velx", 1)
        table.insert(bullets, bullet)
        
        posy = lerp(-Arena.height/2, -y, x)
        bullet = CreateProjectile("attacks/pellet_1", posx, posy)
        bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
        bullet.SetVar("velx", 1)
        table.insert(bullets, bullet)
    end
    
    for i=1,#bullets do
        local bullet = bullets[i]
        if bullet.isactive then
        	local newX = bullet.x - bullet.GetVar("velx")
        	bullet.MoveTo(newX, bullet.y)
        	if newX <= -Arena.width/2 then
        		bullet.Remove()
        	end
        end
    end
end

function OnHit(bullet)
	Player.Hurt(1,0)
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end