local pelletCount = 35
local spawnCount  = 0

spawntimer = 0
bullets = {}

Encounter.SetVar("wavetimer", 3.0)

function Update()
    spawntimer = spawntimer + 1
    if spawntimer%1 == 0 and spawnCount < pelletCount then
    	spawnCount = spawnCount + 1
    	local x = math.cos(math.rad(12 * spawnCount)) * Arena.height/2
    	local y = math.sin(math.rad(12 * spawnCount)) * Arena.height/2
    	local bullet = CreateProjectile("attacks/pellet_1",x,y)
    	bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"}, 1/12.5)
    	local isOrange = math.random() >= 0.5
    	if isOrange then
    		bullet.sprite.color = { 1.00, 0.65, 0.00 }
    	else
    		bullet.sprite.color = { 0.02, 0.37, 0.97 }
    	end
    	bullet.SetVar("isOrange", isOrange)
    	bullet.SetVar("moving", false)
    	bullet.SetVar("dirX", -bullet.x / 100)
    	bullet.SetVar("dirY", -bullet.y / 100)
    	Audio.PlaySound("pellet")
    	table.insert(bullets, bullet)
    end
    
    for i=1,#bullets do
        local bullet = bullets[i]
        if bullet.isactive then
        	if not bullet.GetVar("moving") then
        		if spawntimer == 40 then
        			bullet.SetVar("moving", true)
        		end
        	else
        		bullet.Move(bullet.GetVar("dirX"),bullet.GetVar("dirY"))
        		if dist(bullet.x,bullet.y,0,0) < 1 then
        			bullet.Remove()
        		end
        	end
        end
    end
end

function OnHit(bullet)
    if bullet.isactive and ((bullet.GetVar("isOrange") and not Player.ismoving) or Player.ismoving) then
    	Player.Hurt(1, 0)
    end
end

function dist(ax, ay, bx, by)
	local xd = bx - ax
	local yd = by - ay
	return math.sqrt((xd*xd)+(yd*yd))
end