bullets    = {}
spawntimer = 0

pelletCount = 10

Arena.Resize(500, 300)
Encounter.SetVar("wavetimer", 15.0)

function Update()
	spawntimer = spawntimer + 1
	if spawntimer == 0 or spawntimer%30 == 0 then
		local angle = 360 / pelletCount
		local cx	= Player.absx
		local cy	= Player.absy
		for i=1,pelletCount do
			local bullet = CreateProjectile("attacks/pellet_1", 0, 0)
			bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
			bullet.sprite.color = { 1, 0.65, 0 }
			bullet.SetVar("angle", angle * i)
			bullet.SetVar("dist" , 64)
			bullet.SetVar("timer", 60)
			bullet.SetVar("centerX", cx)
			bullet.SetVar("centerY", cy)
			table.insert(bullets, bullet)
		end
	end
	
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local timer = bullet.GetVar("timer") - 1
			local dst	= bullet.GetVar("dist")
			local ang	= bullet.GetVar("angle") + 90*Time.dt
			if timer <= 0 then
				dst = dst - 300*Time.dt
			end
			if timer == 0 then
				bullet.sprite.color = { 1, 1, 1 }
			end
			local s	= math.sin(math.rad(ang)) * dst
			local c = math.cos(math.rad(ang)) * dst
			local x = bullet.GetVar("centerX") + s
			local y = bullet.GetVar("centerY") + c
			bullet.MoveToAbs(x,y)
			bullet.SetVar("dist", dst)
			bullet.SetVar("angle", ang)
			if x < 0 or x > 640 or y < 0 or y > 480 then
				bullet.Remove()
			end
			bullet.SetVar("timer", timer)
		end
	end
end

function OnHit(bullet)
	if bullet.isactive and (bullet.GetVar("timer") <= 0 or not Player.ismoving) then
		Player.Hurt(1, 0)
	end
end