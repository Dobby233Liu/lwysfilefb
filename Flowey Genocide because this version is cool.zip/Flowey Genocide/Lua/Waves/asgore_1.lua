bullets    = { }
spawntimer = 0

attackCount = math.floor(3 * (GetGlobal("difficulty") * 0.25))
if attackCount > 5 then
	attackCount = 5
end
Encounter.SetVar("wavetimer", 3.5 * attackCount)

local timeToNextAttack = 2.5
local nextAttackLeft   = false
local timeToAttackEnd  = 0
local startedAttack    = false
local firstAttack	   = true

warningLeft = CreateProjectile("attacks/warning_1", -Arena.width/2 + 16, 0)
warningLeft.sprite.SetAnimation({"attacks/warning_1","attacks/warning_2"},1/16)
warningLeft.SetVar("warning", true)
warningLeft.SendToBottom()
warningLeft.sprite.alpha = 0

warningRight = CreateProjectile("attacks/warning_1", Arena.width/2 - 16, 0)
warningRight.sprite.SetAnimation({"attacks/warning_1","attacks/warning_2"},1/16)
warningRight.SetVar("warning", true)
warningRight.SendToBottom()
warningRight.sprite.alpha = 0

pelletAnimations = {{"attacks/pellet_1","attacks/pellet_2"},{"attacks/pellet_2","attacks/pellet_1"}}

function Update()
	spawntimer = spawntimer + 1
	if timeToAttackEnd <= 0 and spawntimer%5 == 0 then
		local bullet = CreateProjectile("attacks/pellet_1", 0, Arena.height/2)
		bullet.sprite.SetAnimation(pelletAnimations[1],1/12.5)
		bullet.SetVar("bulletID", spawntimer)
		bullet.SetVar("wave", false)
		table.insert(bullets, bullet)
	end
	
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			if not bullet.GetVar("wave") then
				local newX = Arena.width/4 * math.sin(Time.time * 0.5 + bullet.GetVar("bulletID"))
				local newY = bullet.y - 1
				bullet.MoveTo(newX, newY)
				if bullet.y <= -Arena.height/2 then
					bullet.Remove()
				end
			else
				bullet.Move(0, 3)
				if bullet.y >= Arena.height/2 then
					bullet.Remove()
				end
			end
		end
	end
	
	if timeToNextAttack > 0 then
		timeToNextAttack = timeToNextAttack - Time.dt
		if timeToNextAttack < 1 then
			if spawntimer%3 == 0 then
				Audio.PlaySound("warning")
			end
			if firstAttack then
				nextAttackLeft = Player.x <= 0
				firstAttack = false
			end
			if nextAttackLeft then
				warningLeft.sprite.alpha = 1
			else
				warningRight.sprite.alpha = 1
			end
		end	
	else
		warningLeft.sprite.alpha = 0
		warningRight.sprite.alpha = 0
		if not startedAttack then
			startedAttack = true
			Audio.PlaySound("pellet_wave")
			timeToAttackEnd = 1
		else
			timeToAttackEnd = timeToAttackEnd - Time.dt
			if spawntimer%3 == 0 then
				local posY = -Arena.height/2
				for i=1,5 do
					local prog = i/5
					local posX = lerp(-Arena.width/2,-Arena.width/2+35,prog)
					if not nextAttackLeft then
						posX = lerp(Arena.width/2, Arena.width/2-35,prog)
					end
					local bullet = CreateProjectile("attacks/pellet_1", posX, posY)
					bullet.sprite.SetAnimation(pelletAnimations[math.random(#pelletAnimations)],1/12.5)
					bullet.SetVar("wave", true)
					table.insert(bullets, bullet)
				end
			end
			if timeToAttackEnd <= 0 then
				timeToNextAttack = 2.5
				nextAttackLeft	 = not nextAttackLeft
				timeToAttackEnd  = 0
				startedAttack 	 = false
			end
		end
	end
end

function OnHit(bullet)
	if not bullet.GetVar("warning") then
		Player.Hurt(1, 0)
	end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end