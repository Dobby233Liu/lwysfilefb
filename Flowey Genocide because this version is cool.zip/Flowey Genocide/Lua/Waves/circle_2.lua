bullets    = { }
spawntimer = 0

patterns = {
{ 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
{ 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
{ 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
}

pelletAnimations = {{"attacks/pellet_1","attacks/pellet_2"},{"attacks/pellet_2","attacks/pellet_1"}}
Encounter.SetVar("wavetimer", 10.0)

function Update()
	spawntimer = spawntimer + 1
	if spawntimer%40 == 0 then
		local pattern  = patterns[math.random(#patterns)]
		local angle    = 360 / #pattern
		local rotSpeed = math.random(1 * GetGlobal("difficulty"), 5 * GetGlobal("difficulty"))
		if math.random() > 0.5 then
			rotSpeed = -rotSpeed
		end
		for i=1,#pattern do
			if pattern[i] == 0 then
				local posX = math.cos(math.rad(angle * i)) * Arena.height*2
				local posY = math.sin(math.rad(angle * i)) * Arena.height*2
				local bullet = CreateProjectile("attacks/pellet_1", posX, posY)
				bullet.sprite.SetAnimation(pelletAnimations[math.random(#pelletAnimations)], 1/12.5)
				bullet.SetVar("dist", 420)
				bullet.SetVar("angle", angle * i)
				bullet.SetVar("rotSpeed", rotSpeed)
				table.insert(bullets, bullet)
			end
		end
	end
	
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local angle = bullet.GetVar("angle") + Time.dt * bullet.GetVar("rotSpeed")
			local dist  = bullet.GetVar("dist") - (Time.dt * 100)
			local newX  = math.cos(math.rad(angle)) * dist
			local newY  = math.sin(math.rad(angle)) * dist
			bullet.MoveTo(newX, newY)
			bullet.SetVar("angle", angle)
			bullet.SetVar("dist" , dist)
			if dist <= 1 then
				bullet.Remove()
			end
		end
	end
end

function OnHit(bullet)
	Player.Hurt(1, 0)
end