bullets    = {}
spawntimer = 0

speed = 5

Encounter.SetVar("wavetimer", 5.0)
Arena.Resize(500, 300)

orange = true

function Update()
	spawntimer = spawntimer + 1
	if spawntimer > 45 and spawntimer%5 == 0 then
		local y		 = -Arena.height/2 + Arena.height*math.random()
		local bullet = CreateProjectile("attacks/pellet_1", -Arena.width/2, y)
		bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
    	if orange then
    		bullet.sprite.color = { 1.00, 0.65, 0.00 }
    	else
    		bullet.sprite.color = { 0.02, 0.37, 0.97 }
    	end
    	bullet.SetVar("orange", orange)
    	table.insert(bullets, bullet)
	end
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local ty = Player.y
			local xd = Arena.width/2  - bullet.x
			local yd = ty - bullet.y
			local dt = Distance(Arena.width/2,ty,bullet.x,bullet.y)
			if bullet.x >= Arena.width/2 then
				bullet.Remove()
			else
				bullet.Move(speed*(xd/dt),speed*(yd/dt))
			end
		end
	end
	if spawntimer%24 == 0 then
		orange = not orange
	end
end

function OnHit(bullet)
	if (bullet.GetVar("orange") and not Player.ismoving) or Player.ismoving then
		Player.Hurt(1, 0)
	end
end

function Distance(x1,y1,x2,y2)
	local x = x2 - x1
	local y = y2 - y1
	return math.sqrt(x*x+y*y)
end