bullets    = {}
spawntimer = 0

left 	= true
gravity = 150

Encounter.SetVar("wavetimer", 10.0)

function Update()
	spawntimer = spawntimer + 1
	if spawntimer%50 == 0 then
		left = not left
		local sprite = "l"
		local posX = 150
		if not left then
			sprite = "r"
			posX = 640 - posX
		end
		local bullet = CreateProjectileAbs("attacks/vinearm_" .. sprite, posX, 517)
		bullet.SetVar("time", 5)
		bullet.SetVar("posX", posX)
		table.insert(bullets, bullet)
	end
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local y = bullet.absy - gravity*Time.dt
			local t = bullet.GetVar("time")
			local x = bullet.GetVar("posX")
			bullet.MoveToAbs(x + 80 * math.sin(t*4.5), y)
			if y < -37 then
				bullet.Remove()
			end
			bullet.SetVar("time", t + Time.dt)
		end
	end
end

function OnHit(bullet)
	Player.Hurt(1, 0)
end