bullets = {}

elapsedFrames = 0
nextAttackTime = 60
top = false

Arena.Resize(47, 74)
Encounter.SetVar("wavetimer", 10.5)

function Update()
	if elapsedFrames < 10 then
		elapsedFrames = elapsedFrames + 1
		top = Player.y > 0
		return
	end
	if warningTop == nil then
		warningTop = CreateProjectile("attacks/vinewarn_1", 0, 18.5)
		warningTop.sprite.StopAnimation()
		warningTop.sprite.SetAnimation({"attacks/vinewarn_1","attacks/vinewarn_2"},1/16)
		warningTop.sprite.alpha = 0
		warningTop.SetVar("warning", true)
		warningTop.SendToBottom()
	end
	if warningBottom == nil then
		warningBottom = CreateProjectile("attacks/vinewarn_1", 0, -18.5)
		warningBottom.sprite.StopAnimation()
		warningBottom.sprite.SetAnimation({"attacks/vinewarn_1","attacks/vinewarn_2"},1/16)
		warningBottom.sprite.alpha = 0
		warningBottom.SetVar("warning", true)
		warningBottom.SendToBottom()
	end
	
	nextAttackTime = nextAttackTime - 1
	warningTop.sprite.alpha = 0
	warningBottom.sprite.alpha = 0
	if nextAttackTime <= 0 then
		nextAttackTime = 45
		Audio.PlaySound("vine_attack")
		
		local posX = 897
		local posY = 18.5
		local type = "r"
		if not top then
			posX = -257
			posY = -18.5
			type = "l"
		end

		local bullet = CreateProjectile("attacks/vinearm_" .. type, 0, posY)
		bullet.sprite.StopAnimation()
        --[[
        in case you're wondering why i'm animating a static sprite, the pellet animation was leaking onto other sprites when it wasn't supposed to.
        so, the only way I could fix it was to replace the animation.
        You can comment out the next to see what I'm talking about, maybe even find a way to fix it! :)
        D2L: Maybe a Unitale bug, didn't see it here
        ]]
		--bullet.sprite.SetAnimation({"attacks/"..sprite},1)
		bullet.MoveToAbs(posX, bullet.absy)
		bullet.SetVar("left", top)
		bullet.SetVar("posX", posX)
		bullet.SetVar("start", Time.time)
		table.insert(bullets, bullet)
		top = not top
	elseif nextAttackTime <= 15 then
		if top then
			warningTop.sprite.alpha = 1
			warningBottom.sprite.alpha = 0
		else
			warningBottom.sprite.alpha = 1
			warningTop.sprite.alpha = 0
		end
		if nextAttackTime%3 == 0 then
			Audio.PlaySound("vine_warning")
		end
	end
	
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			local startX = bullet.GetVar("posX")
			local timer = Time.time - bullet.GetVar("start")
			local off = math.abs(-math.sin(timer*4)) * -514
			local newX = startX - off
			if bullet.GetVar("left") then
				newX = startX + off
			end
			bullet.MoveToAbs(newX, bullet.absy)
			if timer > 0.8 then
				bullet.Remove()
			end
		end
	end
end

function OnHit(bullet)
	if not bullet.GetVar("warning") then
		Player.Hurt(1,0)
	end
end