-- Horribly hacked by d2l for a effect

local bullets    = { }
local spawntimer = 0

Arena.Resize(16,16)

-- Trust me, it won't take that long ;P
Encounter.SetVar("wavetimer", 50)

local pelletDist = 25
local floweyStatus = false
local oldLayer = ""

function Update()
	spawntimer = spawntimer + 1

    if spawntimer == 1 then
        oldLayer = Player.sprite.layer
        -- Visual hax
        Player.sprite.layer = "Top"
    end

	if spawntimer%2 == 0 and spawntimer >= 0 and spawntimer <= 50 then
		local angle = math.rad((360 / 36) * spawntimer)
		local posX  = Player.absx + (math.cos(angle) * pelletDist)
		local posY  = Player.absy + (math.sin(angle) * pelletDist)
		local bullet = CreateProjectileAbs("attacks/pellet_1", posX, posY)
		bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
		bullet.SetVar("angle", angle)
		bullet.SetVar("flash", -1)
		bullet.SetVar("prepremove", false)
		--bulletCount = bulletCount + 1
		table.insert(bullets, bullet)
		Audio.PlaySound("pellet")
	end
	
	if spawntimer%5 == 0 then
		floweyStatus = not floweyStatus
		Encounter.GetVar("enemies")[1].Call("SetFlowey", floweyStatus and "grin2" or "grin1")
		if spawntimer <= 5 then
            Audio.PlaySound("flowey_laugh")
        end
	end

	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
            local contHack = true
            if bullet.absx > 640 or bullet.absx < 0 or bullet.absy > 480 or bullet.absy < 0 then
                bullet.Remove()
                contHack = false
            -- Rev back
            elseif spawntimer >= 60 and pelletDist < 3000 then
                pelletDist = pelletDist + 1
            -- Attack
            elseif spawntimer >= 50 and pelletDist > 0 then
    		    pelletDist = pelletDist - 1
    		end
            if contHack then
    		    local spawnAngle = bullet.GetVar("angle")
    			local posX = Player.absx + (math.cos(spawnAngle) * pelletDist)
    			local posY = Player.absy + (math.sin(spawnAngle) * pelletDist)
    			bullet.MoveToAbs(posX, posY)
    			--[[if bullet.GetVar("flash") >= 0 and spawntimer%math.ceil(bullet.GetVar("flash")/10) == 0 then
    	            bullet.sprite.alpha = bullet.sprite.alpha == 0.25 and 0.75 or 0.25
    	            bullet.SetVar("flash", bullet.GetVar("flash") - 1)
    	        elseif bullet.sprite.alpha < 1 then
                    bullet.sprite.alpha = 1
    	        elseif bullet.GetVar("prepremove") then
                    bullet.Remove()
    	        end]]
            end
		end
	end

    if spawntimer >= 120 then
		spawntimer = 0
        pelletDist = 25
        bullets = {}
	end
end

function EndingWave()
    Player.sprite.layer = oldLayer
end

function OnHit(bullet)
	Player.Hurt(1, 1/100000000000)
	--bullet.SetVar("flash", 50)
	--bullet.SetVar("prepremove", true)
	--bullet.Remove()
end