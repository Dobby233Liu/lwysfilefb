Encounter["wavetimer"] = 0
function Update() EndWave() end