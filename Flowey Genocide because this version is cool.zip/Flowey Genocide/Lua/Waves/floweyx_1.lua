bullets    = { }
spawntimer = 0

Encounter.SetVar("wavetimer", 5.0)

Arena.Resize(16, 150)

function Update()
	spawntimer = spawntimer + 1
	if spawntimer%10 == 0 then
		local posY   = math.random(-Arena.height/2,Arena.height/2)
		local posX   = Arena.width * 3
		local bullet = CreateProjectile("attacks/pellet_1", posX, posY)
		bullet.sprite.SetAnimation({"attacks/pellet_1","attacks/pellet_2"},1/12.5)
		if math.random() <= 0.5 then
			bullet.MoveTo(-Arena.width*3, bullet.y)
			bullet.SetVar("dirX", 1)
		else
			bullet.SetVar("dirX", -1)
		end
		table.insert(bullets, bullet)
	end
	
	for i=1,#bullets do
		local bullet = bullets[i]
		if bullet.isactive then
			bullet.Move(bullet.GetVar("dirX"), 0)
			if (bullet.GetVar("dirX") < 0 and bullet.x <= -Arena.width*3) or (bullet.GetVar("dirX") > 0 and bullet.x >= Arena.width*3) then
				bullet.Remove()
			end
		end
	end
end

function OnHit(bullet)
	Player.Hurt(1, 0)
end